using SQLite;

namespace Gestion_de_personas.Models;

[Table("Personas")]
public class Persona
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [MaxLength(100), NotNull]
    public string Nombre { get; set; } = string.Empty;

    [MaxLength(100)]
    public string Apellido { get; set; } = string.Empty;

    [MaxLength(20)]
    public string Telefono { get; set; } = string.Empty;

    [MaxLength(200)]
    public string Email { get; set; } = string.Empty;

    public byte[]? Foto { get; set; }

    [Ignore]
    public string NombreCompleto => $"{Nombre} {Apellido}".Trim();
    [Ignore]
    public ImageSource? FotoImageSource =>
        Foto is { Length: > 0 }
            ? ImageSource.FromStream(() => new MemoryStream(Foto))
            : null;
}
