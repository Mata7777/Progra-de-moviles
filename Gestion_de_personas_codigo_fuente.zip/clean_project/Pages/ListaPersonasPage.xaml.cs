using Gestion_de_personas.Data;
using Gestion_de_personas.Models;

namespace Gestion_de_personas.Pages;

public partial class ListaPersonasPage : ContentPage
{
    private readonly PersonaDatabase _db;
    private List<Persona> _todas = new();

    public ListaPersonasPage(PersonaDatabase db)
    {
        InitializeComponent();
        _db = db;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await CargarPersonas();
    }

    private async Task CargarPersonas()
    {
        _todas = await _db.GetPersonasAsync();
        AplicarFiltro(SearchBarPersonas.Text);
    }

    private void AplicarFiltro(string? texto)
    {
        if (string.IsNullOrWhiteSpace(texto))
            PersonasCollection.ItemsSource = new List<Persona>(_todas);
        else
        {
            var t = texto.ToLower();
            PersonasCollection.ItemsSource = _todas
                .Where(p => p.NombreCompleto.ToLower().Contains(t) ||
                            p.Telefono.Contains(t) ||
                            p.Email.ToLower().Contains(t))
                .ToList();
        }
    }

    private void OnBuscarTextChanged(object sender, TextChangedEventArgs e)
        => AplicarFiltro(e.NewTextValue);

    private async void OnNuevaPersonaClicked(object sender, EventArgs e)
        => await Shell.Current.GoToAsync("DetallePersona");

    private async void OnEditarClicked(object sender, EventArgs e)
    {
        if (sender is Button btn && btn.CommandParameter is Persona p)
            await Shell.Current.GoToAsync("DetallePersona",
                new Dictionary<string, object> { ["Persona"] = p });
    }

    private async void OnEliminarSwipe(object sender, EventArgs e)
    {
        if (sender is SwipeItem item && item.CommandParameter is Persona p)
        {
            bool ok = await DisplayAlert("Eliminar",
                $"¿Eliminar a {p.NombreCompleto}?", "Sí", "No");
            if (!ok) return;
            await _db.EliminarPersonaAsync(p);
            await CargarPersonas();
        }
    }
}
