using Gestion_de_personas.Data;
using Gestion_de_personas.Models;

namespace Gestion_de_personas.Pages;

[QueryProperty(nameof(Persona), "Persona")]
public partial class DetallePersonaPage : ContentPage
{
    private readonly PersonaDatabase _db;
    private Persona _persona = new();

    public string Titulo => _persona.Id == 0 ? "Nueva Persona" : "Editar Persona";

    public Persona Persona
    {
        get => _persona;
        set
        {
            _persona = value ?? new Persona();
            CargarCampos();
            OnPropertyChanged(nameof(Titulo));
        }
    }

    public DetallePersonaPage(PersonaDatabase db)
    {
        InitializeComponent();
        _db = db;
        BindingContext = this;
    }

    private void CargarCampos()
    {
        NombreEntry.Text = _persona.Nombre;
        ApellidoEntry.Text = _persona.Apellido;
        TelefonoEntry.Text = _persona.Telefono;
        EmailEntry.Text = _persona.Email;
        EliminarBtn.IsVisible = _persona.Id != 0;
        ActualizarFoto();
    }

    private void ActualizarFoto()
    {
        if (_persona.Foto is { Length: > 0 })
        {
            FotoPreview.Source = ImageSource.FromStream(() => new MemoryStream(_persona.Foto));
            FotoPreview.IsVisible = true;
            InicialLabel.IsVisible = false;
        }
        else
        {
            FotoPreview.IsVisible = false;
            InicialLabel.IsVisible = true;
            InicialLabel.Text = !string.IsNullOrWhiteSpace(_persona.Nombre)
                ? _persona.Nombre[0].ToString().ToUpper()
                : "?";
        }
    }

    private void OnNombreChanged(object sender, TextChangedEventArgs e)
    {
        if (!FotoPreview.IsVisible && !string.IsNullOrWhiteSpace(e.NewTextValue))
            InicialLabel.Text = e.NewTextValue[0].ToString().ToUpper();
    }

    private async void OnSeleccionarFotoClicked(object sender, EventArgs e)
    {
        try
        {
            string accion = await DisplayActionSheet(
                "Foto de la persona", "Cancelar", null,
                "📷 Tomar foto", "🖼 Elegir de galería");

            // Verificar cámara antes de intentar capturar
            if (accion == "📷 Tomar foto" && !MediaPicker.Default.IsCaptureSupported)
            {
                await DisplayAlert("No disponible",
                    "Este dispositivo no tiene cámara disponible.", "OK");
                return;
            }

            FileResult? resultado = accion switch
            {
                "📷 Tomar foto" => await MediaPicker.Default.CapturePhotoAsync(),
                "🖼 Elegir de galería" => await MediaPicker.Default.PickPhotoAsync(
                                             new MediaPickerOptions { Title = "Seleccionar foto" }),
                _ => null
            };

            if (resultado == null) return;

            using var stream = await resultado.OpenReadAsync();
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms);
            _persona.Foto = ms.ToArray();
            ActualizarFoto();
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"No se pudo cargar la foto: {ex.Message}", "OK");
        }
    }

    private async void OnGuardarClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NombreEntry.Text))
        {
            await DisplayAlert("Error", "El nombre es obligatorio.", "OK");
            return;
        }

        _persona.Nombre = NombreEntry.Text.Trim();
        _persona.Apellido = ApellidoEntry.Text?.Trim() ?? string.Empty;
        _persona.Telefono = TelefonoEntry.Text?.Trim() ?? string.Empty;
        _persona.Email = EmailEntry.Text?.Trim() ?? string.Empty;

        // Validar duplicado solo al crear
        if (_persona.Id == 0)
        {
            var todas = await _db.GetPersonasAsync();
            bool existe = todas.Any(p =>
                p.Nombre.Equals(_persona.Nombre, StringComparison.OrdinalIgnoreCase) &&
                p.Apellido.Equals(_persona.Apellido, StringComparison.OrdinalIgnoreCase));

            if (existe)
            {
                await DisplayAlert("Duplicado",
                    "Ya existe una persona con ese nombre y apellido.", "OK");
                return;
            }
        }

        await _db.GuardarPersonaAsync(_persona);
        await Shell.Current.GoToAsync("..");
    }

    private async void OnEliminarClicked(object sender, EventArgs e)
    {
        bool ok = await DisplayAlert("Eliminar",
            $"¿Eliminar a {_persona.NombreCompleto}?", "Sí", "No");
        if (!ok) return;

        await _db.EliminarPersonaAsync(_persona);
        await Shell.Current.GoToAsync("..");
    }
}