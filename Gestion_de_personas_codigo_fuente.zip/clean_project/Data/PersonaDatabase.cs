using SQLite;
using Gestion_de_personas.Models;

namespace Gestion_de_personas.Data;

public class PersonaDatabase
{
    private readonly SQLiteAsyncConnection _db;

    public PersonaDatabase(string dbPath)
    {
        _db = new SQLiteAsyncConnection(dbPath);
        _db.CreateTableAsync<Persona>().Wait();
    }

    public Task<List<Persona>> GetPersonasAsync()
        => _db.Table<Persona>().OrderBy(p => p.Nombre).ToListAsync();

    public Task<Persona> GetPersonaAsync(int id)
        => _db.Table<Persona>().Where(p => p.Id == id).FirstOrDefaultAsync();

    public Task<int> GuardarPersonaAsync(Persona persona)
        => persona.Id == 0
            ? _db.InsertAsync(persona)
            : _db.UpdateAsync(persona);

    public Task<int> EliminarPersonaAsync(Persona persona)
        => _db.DeleteAsync(persona);
}
