namespace Gestion_de_personas;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute("DetallePersona", typeof(Pages.DetallePersonaPage));
    }
}
