using Microsoft.Extensions.Logging;
using Gestion_de_personas.Data;
using Gestion_de_personas.Pages;

namespace Gestion_de_personas;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

        string dbPath = Path.Combine(FileSystem.AppDataDirectory, "personas.db3");
        builder.Services.AddSingleton(new PersonaDatabase(dbPath));
        builder.Services.AddTransient<ListaPersonasPage>();
        builder.Services.AddTransient<DetallePersonaPage>();

#if DEBUG
        builder.Logging.AddDebug();
#endif
        return builder.Build();
    }
}
