namespace Examen_I_de_Progra_de_moviles_II
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnComenzarClicked(object sender, EventArgs e)
        {
            Application.Current!.MainPage = new AppShell();
        }
    }
}
