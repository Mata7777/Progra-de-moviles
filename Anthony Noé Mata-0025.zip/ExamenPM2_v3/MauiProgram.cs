using Microsoft.Extensions.Logging;
using Examen_I_de_Progra_de_moviles_II.Data;
using Examen_I_de_Progra_de_moviles_II.Views;
using SkiaSharp.Views.Maui.Controls.Hosting; // Requerido para registrar el handler de SKCanvasView

namespace Examen_I_de_Progra_de_moviles_II
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();

            builder
                .UseMauiApp<App>()
                // UseSkiaSharp() registra el handler de SKCanvasView que Mapsui necesita.
                // Sin esto se lanza HandlerNotFoundException al abrir cualquier página con mapa.
                .UseSkiaSharp()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

            builder.Services.AddSingleton<SitiosDatabase>();
            builder.Services.AddTransient<MainPage>();
            builder.Services.AddTransient<GuardarSitioPage>();
            builder.Services.AddTransient<ListaSitiosPage>();
            builder.Services.AddTransient<MapaSitioPage>();

#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
