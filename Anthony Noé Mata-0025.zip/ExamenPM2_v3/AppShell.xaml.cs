namespace Examen_I_de_Progra_de_moviles_II
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
