using Examen_I_de_Progra_de_moviles_II.Models;
using Mapsui;
using Mapsui.Extensions;
using Mapsui.Layers;
using Mapsui.Projections;
using Mapsui.Tiling;

namespace Examen_I_de_Progra_de_moviles_II.Views
{
    public partial class MapaSitioPage : ContentPage
    {
        private readonly Sitio _sitio;

        public MapaSitioPage(Sitio sitio)
        {
            InitializeComponent();
            _sitio = sitio;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            CargarInfoSitio();
            await VerificarGPS();
            CargarMapa();
        }

        private void CargarInfoSitio()
        {
            lblNombreSitio.Text = _sitio.Descripcion;
            lblCoordenadas.Text = $"Lat: {_sitio.Latitud:F5}  Lon: {_sitio.Longitud:F5}";

            if (!string.IsNullOrEmpty(_sitio.ImagenPath) && File.Exists(_sitio.ImagenPath))
                imgSitioMapa.Source = ImageSource.FromFile(_sitio.ImagenPath);
            else
                imgSitioMapa.Source = "dotnet_bot.png";
        }

        private async Task VerificarGPS()
        {
            try
            {
                var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
                if (status != PermissionStatus.Granted)
                    await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

                var req = new GeolocationRequest(GeolocationAccuracy.Low, TimeSpan.FromSeconds(5));
                var loc = await Geolocation.Default.GetLocationAsync(req);

                if (loc == null)
                    await DisplayAlert("GPS", "GPS inactivo. Mostrando solo la ubicación guardada.", "OK");
            }
            catch (FeatureNotEnabledException)
            {
                await DisplayAlert("GPS Inactivo", "Active el GPS para ver su posición actual en el mapa.", "OK");
            }
            catch { }
        }

        private void CargarMapa()
        {
            var map = new Mapsui.Map();
            map.Layers.Add(OpenStreetMap.CreateTileLayer());

            var coords = SphericalMercator.FromLonLat(_sitio.Longitud, _sitio.Latitud);
            var punto = new MPoint(coords.x, coords.y);

            // Pin rojo — usando namespace completo para evitar ambigüedad
            var pinLayer = new MemoryLayer
            {
                Name = "Pin",
                Features = new List<IFeature>
                {
                    new PointFeature(punto)
                    {
                        Styles = new List<Mapsui.Styles.IStyle>
                        {
                            new Mapsui.Styles.SymbolStyle
                            {
                                SymbolScale = 1.0,
                                Fill = new Mapsui.Styles.Brush(Mapsui.Styles.Color.Red),
                                Outline = new Mapsui.Styles.Pen(Mapsui.Styles.Color.White, 2)
                            }
                        }
                    }
                },
                Style = null
            };

            // Etiqueta con descripción corta
            string desc = _sitio.Descripcion.Length > 25
                ? _sitio.Descripcion[..25] + "..."
                : _sitio.Descripcion;

            var labelLayer = new MemoryLayer
            {
                Name = "Etiqueta",
                Features = new List<IFeature>
                {
                    new PointFeature(new MPoint(punto.X, punto.Y + 30))
                    {
                        Styles = new List<Mapsui.Styles.IStyle>
                        {
                            new Mapsui.Styles.LabelStyle
                            {
                                Text = desc,
                                BackColor = new Mapsui.Styles.Brush(Mapsui.Styles.Color.White),
                                ForeColor = Mapsui.Styles.Color.Black,
                                Font = new Mapsui.Styles.Font { Size = 14 },
                                HorizontalAlignment = Mapsui.Styles.LabelStyle.HorizontalAlignmentEnum.Center
                            }
                        }
                    }
                },
                Style = null
            };

            map.Layers.Add(pinLayer);
            map.Layers.Add(labelLayer);

            map.Navigator.CenterOnAndZoomTo(punto, map.Navigator.Resolutions[15]);
            mapControl.Map = map;
        }

        private async void OnRegresarClicked(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }
    }
}
