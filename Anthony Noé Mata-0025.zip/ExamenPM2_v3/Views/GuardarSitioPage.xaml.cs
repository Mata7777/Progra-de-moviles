using Examen_I_de_Progra_de_moviles_II.Data;
using Examen_I_de_Progra_de_moviles_II.Models;

namespace Examen_I_de_Progra_de_moviles_II.Views
{
    /// <summary>
    /// Página principal de la app. Permite al usuario:
    /// 1. Tomar una foto del sitio con la cámara.
    /// 2. Escribir una descripción (máx 100 caracteres).
    /// 3. Obtener la ubicación GPS actual.
    /// 4. Guardar el sitio en la base de datos SQLite local.
    /// 5. Navegar a la lista de sitios guardados.
    /// </summary>
    public partial class GuardarSitioPage : ContentPage
    {
        // Dependencia inyectada: acceso a la base de datos SQLite
        private readonly SitiosDatabase _db;

        // Ruta local del archivo de imagen tomada con la cámara
        private string _imagenPath = string.Empty;

        // Coordenadas GPS capturadas del dispositivo
        private double _latitud  = 0;
        private double _longitud = 0;

        // Flags que rastrean si cada sección está completa.
        // Los tres deben ser true para habilitar btnGuardar.
        private bool _tieneFoto = false;
        private bool _tieneDesc = false;
        private bool _tieneGPS  = false;

        /// <summary>
        /// Constructor. Recibe SitiosDatabase por inyección de dependencias
        /// registrada en MauiProgram.cs.
        /// </summary>
        public GuardarSitioPage(SitiosDatabase db)
        {
            InitializeComponent();
            _db = db;
        }

        /// <summary>
        /// Evalúa si los tres campos están completos y habilita/deshabilita
        /// el botón Guardar. El Trigger en XAML maneja la Opacity automáticamente,
        /// por lo que aquí solo se cambia IsEnabled.
        /// </summary>
        private void ActualizarEstado()
        {
            bool todo = _tieneFoto && _tieneDesc && _tieneGPS;
            btnGuardar.IsEnabled = todo;
            // Nota: ya NO se toca btnGuardar.Opacity aquí.
            // El Trigger en XAML lo maneja solo al cambiar IsEnabled.
        }

        // ─────────────────────────────────────────────
        // SECCIÓN: FOTOGRAFÍA
        // ─────────────────────────────────────────────

        /// <summary>
        /// Se ejecuta al presionar "Tomar Foto".
        /// Abre la cámara del dispositivo con MediaPicker.
        /// Si el usuario toma la foto:
        ///   - Copia el archivo a AppDataDirectory (almacenamiento permanente).
        ///   - Actualiza imgSitio con la nueva imagen.
        ///   - Oculta el overlay de instrucción.
        ///   - Marca _tieneFoto = true y llama ActualizarEstado().
        /// </summary>
        private async void OnTomarFotoClicked(object sender, EventArgs e)
        {
            try
            {
                // Verificar que el dispositivo tiene cámara disponible
                if (!MediaPicker.Default.IsCaptureSupported)
                {
                    await DisplayAlert("Error", "La cámara no está disponible en este dispositivo.", "OK");
                    return;
                }

                // Deshabilitar botón mientras la cámara está abierta
                btnFoto.IsEnabled = false;
                btnFoto.Text = "📷  Abriendo cámara...";

                // Abrir cámara. Retorna null si el usuario cancela
                var foto = await MediaPicker.Default.CapturePhotoAsync();

                if (foto == null)
                {
                    // Usuario canceló: restaurar botón sin cambiar nada
                    btnFoto.Text = "📷  Tomar Foto";
                    btnFoto.IsEnabled = true;
                    return;
                }

                // Copiar foto al almacenamiento privado de la app para que
                // persista aunque se limpie la caché del dispositivo
                string localPath = Path.Combine(FileSystem.AppDataDirectory, foto.FileName);
                using var stream     = await foto.OpenReadAsync();
                using var fileStream = File.OpenWrite(localPath);
                await stream.CopyToAsync(fileStream);

                // Guardar ruta y mostrar imagen en la UI
                _imagenPath = localPath;
                imgSitio.Source = ImageSource.FromFile(localPath);

                // Ocultar el overlay "Toca el botón para tomar la foto"
                overlayFoto.IsVisible = false;

                // Actualizar estado de la sección
                _tieneFoto = true;
                lblEstadoFoto.Text      = "✅ Foto capturada";
                lblEstadoFoto.TextColor = Color.FromArgb("#28A745");
                btnFoto.Text      = "📷  Cambiar Foto";
                btnFoto.IsEnabled = true;

                ActualizarEstado();
            }
            catch (Exception ex)
            {
                // Error inesperado (permisos, hardware, etc.)
                btnFoto.Text      = "📷  Tomar Foto";
                btnFoto.IsEnabled = true;
                await DisplayAlert("Error", $"No se pudo tomar la foto: {ex.Message}", "OK");
            }
        }

        // ─────────────────────────────────────────────
        // SECCIÓN: DESCRIPCIÓN
        // ─────────────────────────────────────────────

        /// <summary>
        /// Se ejecuta cada vez que el usuario escribe o borra en txtDescripcion.
        /// - Actualiza el contador de caracteres (ej: "23/100").
        /// - Cambia lblEstadoDesc según si hay texto o no.
        /// - Llama ActualizarEstado() para re-evaluar el botón Guardar.
        /// </summary>
        private void OnDescripcionChanged(object sender, TextChangedEventArgs e)
        {
            // Actualizar contador de caracteres en tiempo real
            int len = e.NewTextValue?.Length ?? 0;
            lblContador.Text = $"{len}/100";

            // Validar si hay texto útil (no solo espacios)
            _tieneDesc = !string.IsNullOrWhiteSpace(e.NewTextValue);

            // Cambiar label de estado según resultado
            lblEstadoDesc.Text = _tieneDesc ? "✅ Lista" : "Pendiente";
            lblEstadoDesc.TextColor = _tieneDesc
                ? Color.FromArgb("#28A745")
                : Color.FromArgb("#999999");

            ActualizarEstado();
        }

        // ─────────────────────────────────────────────
        // SECCIÓN: GPS
        // ─────────────────────────────────────────────

        /// <summary>
        /// Se ejecuta al presionar "Obtener Ubicación GPS".
        /// Flujo:
        ///   1. Muestra spinner loadingGPS.
        ///   2. Solicita permiso LocationWhenInUse al sistema operativo.
        ///   3. Llama Geolocation.GetLocationAsync con precisión Media y timeout 10s.
        ///   4. Si obtiene ubicación: llena lblLatitud/lblLongitud, marca borde verde.
        ///   5. Si falla: muestra alerta y llama ResetearGPS().
        /// </summary>
        private async void OnObtenerUbicacionClicked(object sender, EventArgs e)
        {
            try
            {
                // Mostrar estado de carga
                btnGPS.IsEnabled  = false;
                btnGPS.Text       = "📍  Buscando...";
                loadingGPS.IsVisible = true;
                lblEstadoGPS.Text      = "Obteniendo...";
                lblEstadoGPS.TextColor = Color.FromArgb("#FFC107"); // amarillo = en proceso

                // Solicitar permiso de ubicación al OS.
                // En Android pide el diálogo de permisos la primera vez.
                var status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
                if (status != PermissionStatus.Granted)
                {
                    await DisplayAlert("Permiso denegado", "Se necesita acceso a la ubicación.", "OK");
                    ResetearGPS();
                    return;
                }

                // Solicitar ubicación con precisión Media y timeout de 10 segundos
                var request  = new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(10));
                var location = await Geolocation.Default.GetLocationAsync(request);

                // Ocultar spinner independientemente del resultado
                loadingGPS.IsVisible = false;

                if (location != null)
                {
                    // Guardar coordenadas como números
                    _latitud  = location.Latitude;
                    _longitud = location.Longitude;

                    // Mostrar con 6 decimales (precisión de ~10 cm)
                    lblLatitud.Text  = _latitud.ToString("F6");
                    lblLongitud.Text = _longitud.ToString("F6");

                    // Actualizar UI a estado exitoso
                    _tieneGPS = true;
                    lblEstadoGPS.Text       = "✅ Ubicación obtenida";
                    lblEstadoGPS.TextColor  = Color.FromArgb("#28A745");
                    btnGPS.Text             = "📍  Actualizar GPS";
                    btnGPS.IsEnabled        = true;

                    // Cambiar borde del Frame a verde para indicar éxito visual
                    frameCoords.BorderColor = Color.FromArgb("#28A745");
                }
                else
                {
                    // La API devolvió null: GPS activo pero sin señal
                    await DisplayAlert("GPS", "No se pudo obtener la ubicación. Verifique que el GPS esté activo.", "OK");
                    ResetearGPS();
                }

                ActualizarEstado();
            }
            catch (FeatureNotEnabledException)
            {
                // El GPS del dispositivo está apagado
                loadingGPS.IsVisible = false;
                await DisplayAlert("GPS Inactivo",
                    "El GPS está desactivado. Por favor actívelo en la configuración del dispositivo.", "OK");
                ResetearGPS();
            }
            catch (Exception ex)
            {
                // Cualquier otro error (timeout, sin permisos en tiempo de ejecución, etc.)
                loadingGPS.IsVisible = false;
                await DisplayAlert("Error", $"Error al obtener ubicación: {ex.Message}", "OK");
                ResetearGPS();
            }
        }

        /// <summary>
        /// Resetea la sección GPS a su estado inicial.
        /// Se llama cuando hay un error o el permiso es denegado.
        /// </summary>
        private void ResetearGPS()
        {
            btnGPS.Text             = "📍  Obtener Ubicación GPS";
            btnGPS.IsEnabled        = true;
            lblEstadoGPS.Text       = "No obtenida";
            lblEstadoGPS.TextColor  = Color.FromArgb("#999999");
            _tieneGPS               = false;
            ActualizarEstado();
        }

        // ─────────────────────────────────────────────
        // SECCIÓN: GUARDAR
        // ─────────────────────────────────────────────

        /// <summary>
        /// Se ejecuta al presionar "Guardar Sitio".
        /// Solo accesible cuando _tieneFoto && _tieneDesc && _tieneGPS son true.
        /// Flujo:
        ///   1. Muestra diálogo de confirmación con resumen.
        ///   2. Crea objeto Sitio con los datos recolectados.
        ///   3. Lo guarda en SQLite con _db.GuardarSitioAsync().
        ///   4. Resetea toda la UI al estado inicial para un nuevo registro.
        /// </summary>
        private async void OnGuardarClicked(object sender, EventArgs e)
        {
            // Confirmación antes de guardar para evitar guardados accidentales
            bool confirmar = await DisplayAlert(
                "Confirmar",
                $"¿Desea guardar este sitio?\n\n📝 {txtDescripcion.Text.Trim()}\n📍 Lat: {_latitud:F4}, Lon: {_longitud:F4}",
                "Guardar", "Cancelar");

            if (!confirmar) return;

            // Deshabilitar botón para evitar doble guardado mientras procesa
            btnGuardar.IsEnabled = false;
            btnGuardar.Text      = "💾  Guardando...";

            // Construir el modelo con los datos recolectados en la sesión
            var sitio = new Sitio
            {
                Descripcion = txtDescripcion.Text.Trim(),
                Latitud     = _latitud,
                Longitud    = _longitud,
                ImagenPath  = _imagenPath
            };

            // Persistir en SQLite (operación asíncrona)
            await _db.GuardarSitioAsync(sitio);
            await DisplayAlert("✅ Éxito", "Sitio guardado correctamente.", "OK");

            // ── Reset completo de toda la UI ──
            // Limpiar campos de texto y coordenadas
            txtDescripcion.Text  = string.Empty;
            lblLatitud.Text      = "--";
            lblLongitud.Text     = "--";
            lblContador.Text     = "0/100";

            // Restaurar imagen al placeholder y mostrar overlay
            imgSitio.Source       = "dotnet_bot.png";
            overlayFoto.IsVisible = true;

            // Limpiar variables de estado
            _imagenPath = string.Empty;
            _latitud    = 0;
            _longitud   = 0;
            _tieneFoto  = false;
            _tieneDesc  = false;
            _tieneGPS   = false;

            // Restaurar labels de estado a su valor inicial
            lblEstadoFoto.Text      = "Pendiente";
            lblEstadoFoto.TextColor = Color.FromArgb("#999999");
            lblEstadoDesc.Text      = "Pendiente";
            lblEstadoDesc.TextColor = Color.FromArgb("#999999");
            lblEstadoGPS.Text       = "No obtenida";
            lblEstadoGPS.TextColor  = Color.FromArgb("#999999");

            // Restaurar texto de botones
            btnFoto.Text = "📷  Tomar Foto";
            btnGPS.Text  = "📍  Obtener Ubicación GPS";
            btnGPS.IsEnabled = true;

            // Restaurar borde del Frame de coordenadas a gris neutro
            frameCoords.BorderColor = Color.FromArgb("#D0D0D0");

            // Restaurar texto del botón Guardar (IsEnabled lo maneja ActualizarEstado)
            btnGuardar.Text = "💾  Guardar Sitio";

            // Re-evaluar estado → deshabilita btnGuardar ya que todo está en false
            ActualizarEstado();
        }

        // ─────────────────────────────────────────────
        // NAVEGACIÓN
        // ─────────────────────────────────────────────

        /// <summary>
        /// Se ejecuta al presionar "Ver Lista".
        /// Navega a ListaSitiosPage usando la ruta registrada en AppShell.
        /// Shell.GoToAsync es el método estándar de navegación en MAUI Shell.
        /// </summary>
        private async void OnVerListaClicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("//ListaSitiosPage");
        }
    }
}
