using Examen_I_de_Progra_de_moviles_II.Data;
using Examen_I_de_Progra_de_moviles_II.Models;

namespace Examen_I_de_Progra_de_moviles_II.Views
{
    public partial class ListaSitiosPage : ContentPage
    {
        private readonly SitiosDatabase _db;

        public ListaSitiosPage(SitiosDatabase db)
        {
            InitializeComponent();
            _db = db;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await CargarSitios();
        }

        private async Task CargarSitios()
        {
            activityIndicator.IsVisible = true;
            activityIndicator.IsRunning = true;

            var sitios = await _db.GetSitiosAsync();
            listaSitios.ItemsSource = sitios;

            activityIndicator.IsRunning = false;
            activityIndicator.IsVisible = false;
        }

        private async void OnVerMapaClicked(object sender, EventArgs e)
        {
            if (sender is Button btn && btn.CommandParameter is Sitio sitio)
            {
                await Navigation.PushModalAsync(new NavigationPage(new MapaSitioPage(sitio)));
            }
        }

        private async void OnCompartirClicked(object sender, EventArgs e)
        {
            if (sender is Button btn && btn.CommandParameter is Sitio sitio)
            {
                if (string.IsNullOrEmpty(sitio.ImagenPath) || !File.Exists(sitio.ImagenPath))
                {
                    await DisplayAlert("Error", "No se encontró la imagen del sitio.", "OK");
                    return;
                }

                await Share.Default.RequestAsync(new ShareFileRequest
                {
                    Title = $"Sitio: {sitio.Descripcion}",
                    File = new ShareFile(sitio.ImagenPath)
                });
            }
        }

        private async void OnEliminarClicked(object sender, EventArgs e)
        {
            if (sender is Button btn && btn.CommandParameter is Sitio sitio)
            {
                bool confirmar = await DisplayAlert("Eliminar",
                    $"¿Desea eliminar '{sitio.Descripcion}'?",
                    "Sí, eliminar", "Cancelar");

                if (!confirmar) return;

                if (!string.IsNullOrEmpty(sitio.ImagenPath) && File.Exists(sitio.ImagenPath))
                    try { File.Delete(sitio.ImagenPath); } catch { }

                await _db.EliminarSitioAsync(sitio);
                await CargarSitios();
            }
        }
    }
}
