using SQLite;
using Examen_I_de_Progra_de_moviles_II.Models;

namespace Examen_I_de_Progra_de_moviles_II.Data
{
    public class SitiosDatabase
    {
        private SQLiteAsyncConnection? _database;

        private async Task Init()
        {
            if (_database is not null)
                return;

            string dbPath = Path.Combine(FileSystem.AppDataDirectory, "sitios.db3");
            _database = new SQLiteAsyncConnection(dbPath);
            await _database.CreateTableAsync<Sitio>();
        }

        public async Task<List<Sitio>> GetSitiosAsync()
        {
            await Init();
            return await _database!.Table<Sitio>().ToListAsync();
        }

        public async Task<int> GuardarSitioAsync(Sitio sitio)
        {
            await Init();
            if (sitio.Id != 0)
                return await _database!.UpdateAsync(sitio);
            else
                return await _database!.InsertAsync(sitio);
        }

        public async Task<int> EliminarSitioAsync(Sitio sitio)
        {
            await Init();
            return await _database!.DeleteAsync(sitio);
        }
    }
}
