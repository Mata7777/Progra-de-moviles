using SQLite;

namespace Examen_I_de_Progra_de_moviles_II.Models
{
    public class Sitio
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string Descripcion { get; set; } = string.Empty;
        public double Latitud { get; set; }
        public double Longitud { get; set; }

        // Imagen guardada como ruta al archivo local
        public string ImagenPath { get; set; } = string.Empty;
    }
}
