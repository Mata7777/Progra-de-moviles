using System;
using Microsoft.Maui;
using Microsoft.Maui.Hosting;

namespace Examen_I_de_Progra_de_moviles_II
{
    internal class Program : MauiApplication
    {
        protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();

        static void Main(string[] args)
        {
            var app = new Program();
            app.Run(args);
        }
    }
}
