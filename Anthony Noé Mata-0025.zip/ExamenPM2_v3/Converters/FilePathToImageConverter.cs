using System.Globalization;

namespace Examen_I_de_Progra_de_moviles_II.Converters
{
    /// <summary>
    /// Convierte una ruta de archivo local (string) a ImageSource para mostrar en binding.
    /// </summary>
    public class FilePathToImageConverter : IValueConverter
    {
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is string path && !string.IsNullOrEmpty(path) && File.Exists(path))
                return ImageSource.FromFile(path);

            // Imagen placeholder si no existe el archivo
            return ImageSource.FromFile("photo_placeholder.png");
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
